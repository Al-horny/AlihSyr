import repositories.IOrderRepository;
import repositories.OrderRepository;

public class Main {
    public static void main(String[] args) {
        IOrderRepository iOrderRepository = new OrderRepository();
        Application project = new Application(iOrderRepository);
        project.start();
    }
}
