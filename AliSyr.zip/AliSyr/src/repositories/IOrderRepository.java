package repositories;

import entities.Customer;
import entities.Orders;
import entities.Products;

import java.util.List;
public interface IOrderRepository {
    Customer getCustomer(int id);
    List<Customer> getAllCustomerList();
    Customer getCustomerPhone(int phone);
    List<Products> getAllProductsList();
    List<Orders> getOrderList(int customer_id);
    boolean mintCustomer(Customer customer);
    boolean mintProduct(Products products);
}
