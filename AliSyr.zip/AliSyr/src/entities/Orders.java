package entities;

public class Orders {
    private int order_id,product_id,customer_id;

    public Orders(int order_id, int product_id, int customer_id) {
        this.order_id = order_id;
        this.product_id = product_id;
        this.customer_id = customer_id;
    }

    public Orders(int product_id, int customer_id) {
        this.product_id = product_id;
        this.customer_id = customer_id;
    }

    public int getId() {
        return order_id;
    }

    public void setId(int order_id) {
        this.order_id = order_id;
    }

    public int getProduct_id() {
        return product_id;
    }

    public void setProduct_id(int Product_id) {
        this.product_id = product_id;
    }

    public int getCustomer_id() {
        return customer_id;
    }

    public void setCustomer_id(int customer_id) {
        this.customer_id = customer_id;
    }

    @Override
    public String toString() {
        return "Products{" +
                "id=" + order_id +
                ", product_id='" + product_id + '\'' +
                ", customer_id='" + customer_id + '\'' +
                '}';
    }
}
