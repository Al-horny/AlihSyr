package controllers;

import entities.Customer;
import entities.Products;
import entities.Orders;
import repositories.IOrderRepository;

import java.util.List;

public class ControlOrder {
    private final IOrderRepository iOrderRepository;

    public ControlOrder(IOrderRepository iOrderRepository) {
        this.iOrderRepository = iOrderRepository;
    }

    public String getCustomer(int id) {
        Customer customer = iOrderRepository.getCustomer(id);
        return (customer == null ? "Customer not found,try again!" : customer.toString());
    }
    public String getCustomerPhone(int phone) {
        Customer customer = iOrderRepository.getCustomerPhone(phone);
        return (customer == null ? "Customer not found,try again!" : customer.toString());
    }
    public int getCustomerIDbyPhone(int phone) {
        Customer customer = iOrderRepository.getCustomerPhone(phone);
        return customer.getId();
    }
    public void getAllCustomerList() {
        List<Customer> customers = iOrderRepository.getAllCustomerList();

        for (Customer c : customers) {
            System.out.println("Customer ID: " + c.getId() + " - Name: " + c.getName() + " - Phone number: " + c.getPhone());
        }
    }
    public void getAllProductList() {
        List<Products> products = iOrderRepository.getAllProductsList();

        for (Products p : products) {
            System.out.println("Product ID: " + p.getId() + " - Product name: " + p.getPname() + " - Price: " + p.getPrice());
        }
    }
    public void getOrderList(int Customer_id) {
        List<Orders> orders = iOrderRepository.getOrderList(Customer_id);

        for (Orders p : orders) {
            System.out.println("Order ID: " + p.getId() + " - Product ID: " + p.getProduct_id() + " - Customer ID: " + p.getCustomer_id());
        }
    }
    public String mintNewCustomers(String name, int phoneNumber) {
        Customer customer = new Customer(name, phoneNumber);
        boolean created = iOrderRepository.mintCustomer(customer);
        return (created ? "Customer authorization was failed!" : "Customer has been successfully authorized!");
    }
    public String mintNewProduct(String pname, String price) {
        Products product = new Products(pname, price);
        boolean created = iOrderRepository.mintProduct(product);
        return (created ? "Product creating was failed!" : "Product has been successfully added!");
    }
 }